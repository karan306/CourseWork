#!/bin/bash

filename=$1
# echo $filename
python3 value_iteration.py $filename