#!/bin/bash

filename=$1
# echo $filename
python3 decoder.py $1 $2 $3