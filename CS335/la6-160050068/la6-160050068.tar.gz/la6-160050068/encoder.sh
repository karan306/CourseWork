#!/bin/bash

filename=$1
# echo $filename
python3 encoder.py $1 $2